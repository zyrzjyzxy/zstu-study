
import { useState } from 'react'
import api from '../api'
import { useNavigate } from 'react-router-dom'
export default function Login(){
  const [username,setUsername] = useState('dispatcher')
  const [password,setPassword] = useState('123456')
  const [error,setError] = useState('')
  const nav = useNavigate()
  async function submit(e:any){
    e.preventDefault()
    try{
      const res = await api.post('/auth/login', {username, password})
      localStorage.setItem('token', res.data.access_token)
      localStorage.setItem('user', username)
      nav('/')
    }catch(err:any){ setError(err?.response?.data?.detail || '登录失败') }
  }
  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={submit} className="card w-full max-w-sm">
        <div className="text-xl font-bold mb-4 text-center">安燃云 · 登录</div>
        <div className="mb-3"><label className="block mb-1 text-sm">用户名</label><input className="input" value={username} onChange={e=>setUsername(e.target.value)} /></div>
        <div className="mb-3"><label className="block mb-1 text-sm">密码</label><input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} /></div>
        {error && <div className="text-red-600 text-sm mb-2">{error}</div>}
        <button className="btn w-full">登录</button>
      </form>
    </div>
  )
}

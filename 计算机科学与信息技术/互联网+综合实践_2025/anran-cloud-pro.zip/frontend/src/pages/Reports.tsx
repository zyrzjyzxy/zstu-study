
export default function Reports(){
  const base = import.meta.env.VITE_API_URL as string
  return (
    <div className="card">
      <div className="font-bold mb-2">报表与导出</div>
      <div className="space-x-3">
        <a className="btn" href={`${base}/reports/daily.csv`} target="_blank">导出 CSV</a>
        <a className="btn" href={`${base}/reports/daily.pdf`} target="_blank">导出 PDF</a>
      </div>
    </div>
  )
}

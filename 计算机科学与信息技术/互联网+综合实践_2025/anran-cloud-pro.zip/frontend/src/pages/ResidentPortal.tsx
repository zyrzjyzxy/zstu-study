
import { useState } from 'react'
import api from '../api'
export default function ResidentPortal(){
  const [address, setAddress] = useState('学生公寓 3 栋 2 单元')
  const [note, setNote] = useState('闻到疑似燃气异味')
  const [file, setFile] = useState<File | null>(null)
  const [msg, setMsg] = useState('')
  async function submit(){
    const form = new FormData()
    form.append('address', address)
    form.append('note', note)
    if (file) form.append('file', file)
    const res = await api.post('/residents/odor', form, { headers:{'Content-Type':'multipart/form-data'} })
    setMsg('已上报，告警编号 #' + res.data.alert_id)
  }
  return (
    <div className="card max-w-xl">
      <div className="font-bold mb-2">居民端 · 异味快报（上传证据）</div>
      <div className="mb-3"><label className="block text-sm mb-1">位置/地址</label><input className="input" value={address} onChange={e=>setAddress(e.target.value)} /></div>
      <div className="mb-3"><label className="block text-sm mb-1">备注</label><input className="input" value={note} onChange={e=>setNote(e.target.value)} /></div>
      <div className="mb-3"><label className="block text-sm mb-1">证据图片（可选）</label><input type="file" onChange={e=>setFile(e.target.files?.[0]||null)} /></div>
      <button className="btn" onClick={submit}>一键求助</button>
      {msg && <div className="mt-3 text-green-700">{msg}</div>}
    </div>
  )
}


import { useEffect, useState } from 'react'
import api from '../api'
type Alert = { id:number, device_id:number, level:string, message:string, confidence:number, created_at:string, status:string }
export default function Alerts(){
  const [alerts, setAlerts] = useState<Alert[]>([])
  async function load(){ const res = await api.get('/alerts'); setAlerts(res.data) }
  useEffect(()=>{ load() }, [])
  async function ack(id:number){ await api.post('/alerts/'+id+'/ack'); load() }
  async function close(id:number){ await api.post('/alerts/'+id+'/close'); load() }
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-2"><div className="font-bold">告警列表（实时）</div><button className="btn" onClick={load}>刷新</button></div>
      <table className="table">
        <thead><tr><th>ID</th><th>设备</th><th>等级</th><th>说明</th><th>置信度</th><th>时间</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
        {alerts.map(a=>(
          <tr key={a.id}>
            <td>{a.id}</td><td>{a.device_id}</td><td>{a.level}</td>
            <td className="max-w-[320px] truncate">{a.message}</td>
            <td>{(a.confidence*100).toFixed(0)}%</td>
            <td>{new Date(a.created_at).toLocaleString()}</td>
            <td>{a.status}</td>
            <td className="space-x-2">
              <button className="btn" onClick={()=>ack(a.id)}>确认</button>
              <button className="btn" onClick={()=>close(a.id)}>关闭</button>
            </td>
          </tr>
        ))}
        </tbody>
      </table>
    </div>
  )
}

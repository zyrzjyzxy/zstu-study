
import { useEffect, useMemo, useState } from 'react'
import api from '../api'
import DeviceMap from '../components/DeviceMap'
import TimeSeriesChart from '../components/TimeSeriesChart'
import Toast from '../components/Toast'

type Alert = { id:number, device_id:number, level:string, message:string, confidence:number, created_at:string, status:string }
type Device = { id:number, name:string, lat:number, lng:number, location_desc:string }

export default function Dashboard(){
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [devices, setDevices] = useState<Device[]>([])
  const [selected, setSelected] = useState<number | null>(null)
  const [series, setSeries] = useState<any[]>([])
  const [toast, setToast] = useState<string>('')

  async function refreshBasics(){
    const [a,d] = await Promise.all([api.get('/alerts'), api.get('/devices')])
    setAlerts(a.data); setDevices(d.data)
    if (!selected && d.data.length) setSelected(d.data[0].id)
  }
  async function loadSeries(){
    if (!selected) return
    const res = await api.get(`/devices/${selected}/timeseries`, { params: { hours: 6 } })
    setSeries(res.data.points)
  }

  useEffect(()=>{ refreshBasics() }, [])
  useEffect(()=>{ loadSeries() }, [selected])

  useEffect(()=>{
    const wsUrl = import.meta.env.VITE_WS_URL as string
    let ws: WebSocket | null = null
    try { ws = new WebSocket(wsUrl) } catch {}
    if (!ws) return
    ws.onmessage = (ev)=>{
      try{
        const msg = JSON.parse(ev.data)
        if (msg.type==='alert'){
          setToast(`新告警 #${msg.id} [${msg.level}] 设备${msg.device_id}`)
          refreshBasics()
        }
      }catch{}
    }
    return ()=>{ ws && ws.close() }
  }, [])

  const openCount = useMemo(()=>alerts.filter(a=>a.status!=='closed').length,[alerts])

  return (
    <div className="space-y-6">
      {toast && <Toast message={toast} />}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card"><div className="text-sm text-slate-500">设备数量</div><div className="text-3xl font-bold">{devices.length}</div></div>
        <div className="card"><div className="text-sm text-slate-500">当前告警</div><div className="text-3xl font-bold">{openCount}</div></div>
        <div className="card"><div className="text-sm text-slate-500">选中设备</div>
          <select className="input mt-2" value={selected ?? ''} onChange={e=>setSelected(Number(e.target.value))}>
            {devices.map(d=><option key={d.id} value={d.id}>{d.id} - {d.name}</option>)}
          </select>
        </div>
      </div>

      <div className="card"><div className="font-bold mb-2">GIS 设备分布</div><DeviceMap devices={devices} alerts={alerts} /></div>
      <div className="card">
        <div className="flex items-center justify-between mb-2"><div className="font-bold">近6小时时序（压力/流量/温度）</div><button className="btn" onClick={loadSeries}>刷新</button></div>
        <TimeSeriesChart series={series} />
      </div>
    </div>
  )
}

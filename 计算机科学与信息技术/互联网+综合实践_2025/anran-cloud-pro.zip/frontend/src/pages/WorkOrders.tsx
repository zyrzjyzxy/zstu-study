
import { useEffect, useState } from 'react'
import api from '../api'
type WorkOrder = { id:number, alert_id?:number, title:string, assignee:string, status:string, sla_minutes:number, created_at:string }
type Alert = { id:number, message:string }
export default function WorkOrders(){
  const [wos, setWos] = useState<WorkOrder[]>([])
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [form, setForm] = useState({alert_id: '', title:'现场核查', assignee:'field', sla_minutes:30, details:''})
  async function load(){ const res = await api.get('/workorders'); setWos(res.data) }
  async function loadAlerts(){ const res = await api.get('/alerts'); setAlerts(res.data) }
  useEffect(()=>{ load(); loadAlerts()}, [])
  async function createWO(){ if (!form.alert_id) return; await api.post('/workorders/from_alert/'+form.alert_id, {title:form.title, assignee:form.assignee, sla_minutes:form.sla_minutes, details:form.details}); setForm({...form, details:''}); load() }
  async function updateStatus(id:number, s:string){ await api.post(`/workorders/${id}/status/${s}`); load() }
  return (
    <div className="space-y-6">
      <div className="card">
        <div className="font-bold mb-2">由告警生成工单</div>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <select className="input" value={form.alert_id} onChange={e=>setForm({...form, alert_id:e.target.value})}>
            <option value="">选择告警</option>
            {alerts.map((a:any)=>(<option key={a.id} value={a.id}>#{a.id} - {a.message.slice(0,20)}</option>))}
          </select>
          <input className="input" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
          <input className="input" value={form.assignee} onChange={e=>setForm({...form, assignee:e.target.value})} />
          <input className="input" type="number" value={form.sla_minutes} onChange={e=>setForm({...form, sla_minutes:Number(e.target.value)})} />
          <button className="btn" onClick={createWO}>生成</button>
        </div>
      </div>
      <div className="card">
        <div className="font-bold mb-2">工单列表</div>
        <table className="table">
          <thead><tr><th>ID</th><th>告警</th><th>标题</th><th>指派</th><th>SLA</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
          {wos.map(w=>(
            <tr key={w.id}>
              <td>{w.id}</td><td>{w.alert_id || '-'}</td><td>{w.title}</td><td>{w.assignee}</td><td>{w.sla_minutes}min</td><td>{w.status}</td>
              <td className="space-x-2">{["assigned","on_site","processing","retest","closed"].map(s=>(<button key={s} className="btn" onClick={()=>updateStatus(w.id, s)}>{s}</button>))}</td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

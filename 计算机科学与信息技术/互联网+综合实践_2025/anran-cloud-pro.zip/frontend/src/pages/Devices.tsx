
import { useEffect, useState } from 'react'
import api from '../api'
type Device = { id:number, name:string, lat:number, lng:number, location_desc:string, active:boolean }
export default function Devices(){
  const [list, setList] = useState<Device[]>([])
  const [form, setForm] = useState({name:'新站点', lat:30.582, lng:114.300, location_desc:'备注'})
  async function load(){ const res = await api.get('/devices'); setList(res.data) }
  useEffect(()=>{ load() }, [])
  async function add(){ await api.post('/devices/register', form); setForm({...form, name:'新站点'}); load() }
  async function toggle(id:number, flag:boolean){ await api.post(`/devices/${id}/activate/${flag}`); load() }
  return (
    <div className="space-y-6">
      <div className="card">
        <div className="font-bold mb-2">新增设备</div>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <input className="input" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
          <input className="input" type="number" step="0.0001" value={form.lat} onChange={e=>setForm({...form, lat:Number(e.target.value)})} />
          <input className="input" type="number" step="0.0001" value={form.lng} onChange={e=>setForm({...form, lng:Number(e.target.value)})} />
          <input className="input" value={form.location_desc} onChange={e=>setForm({...form, location_desc:e.target.value})} />
          <button className="btn" onClick={add}>注册</button>
        </div>
      </div>
      <div className="card">
        <div className="font-bold mb-2">设备列表</div>
        <table className="table">
          <thead><tr><th>ID</th><th>名称</th><th>坐标</th><th>位置</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
          {list.map(d=>(
            <tr key={d.id}>
              <td>{d.id}</td><td>{d.name}</td><td>{d.lat.toFixed(4)},{d.lng.toFixed(4)}</td><td>{d.location_desc}</td>
              <td>{d.active ? '启用' : '停用'}</td>
              <td>{d.active ? <button className="btn" onClick={()=>toggle(d.id,false)}>停用</button> : <button className="btn" onClick={()=>toggle(d.id,true)}>启用</button>}</td>
            </tr>
          ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

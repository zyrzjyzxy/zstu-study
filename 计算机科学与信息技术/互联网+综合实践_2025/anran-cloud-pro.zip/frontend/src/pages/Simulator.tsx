
export default function Simulator(){
  const base = import.meta.env.VITE_API_URL as string
  return (
    <div className="card">
      <div className="font-bold mb-2">模拟器控制</div>
      <div className="space-x-2">
        <a className="btn" href={`${base}/simulator/start`} target="_blank" rel="noreferrer">启动</a>
        <a className="btn" href={`${base}/simulator/stop`} target="_blank" rel="noreferrer">停止</a>
      </div>
      <p className="text-sm text-slate-600 mt-2">模拟器按设定间隔向所有启用设备注入时序数据，随机触发异常以验证告警与闭环。</p>
    </div>
  )
}

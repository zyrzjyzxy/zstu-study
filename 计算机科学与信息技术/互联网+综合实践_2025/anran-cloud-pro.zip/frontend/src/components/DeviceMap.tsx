
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import { useMemo } from 'react'

const icon = new L.Icon({ iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconSize:[25,41], iconAnchor:[12,41], popupAnchor:[1,-34], shadowSize:[41,41] })

export default function DeviceMap({ devices, alerts }:{devices:any[], alerts:any[]}){
  const center = devices.length ? [devices[0].lat, devices[0].lng] : [30.58,114.30]
  const openSet = new Set(alerts.filter((a:any)=>a.status!=='closed').map((a:any)=>a.device_id))
  const markers = useMemo(()=>devices.map(d=>(
    <Marker key={d.id} position={[d.lat,d.lng]} icon={icon}>
      <Popup>
        <div className="text-sm font-bold">{d.name}</div>
        <div className="text-xs text-slate-600">{d.location_desc}</div>
        <div className="text-xs mt-1">状态：{openSet.has(d.id) ? '⚠️ 有告警' : '✅ 正常'}</div>
      </Popup>
    </Marker>
  )),[devices, alerts])
  return (
    <MapContainer center={center as any} zoom={14} scrollWheelZoom={false}>
      <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {markers}
    </MapContainer>
  )
}

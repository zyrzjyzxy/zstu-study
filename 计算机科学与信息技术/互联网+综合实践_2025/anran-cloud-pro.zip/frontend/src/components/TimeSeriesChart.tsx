
import { Line } from 'react-chartjs-2'
import { Chart, LineElement, PointElement, LinearScale, TimeScale, CategoryScale, Legend, Tooltip } from 'chart.js'
Chart.register(LineElement, PointElement, LinearScale, TimeScale, CategoryScale, Legend, Tooltip)

export default function TimeSeriesChart({ series }:{ series:{ts:string, pressure:number, flow:number, temp:number}[] }){
  const labels = series.map(p=> new Date(p.ts).toLocaleTimeString())
  const data = { labels, datasets: [
    { label:'pressure', data: series.map(p=>p.pressure) },
    { label:'flow', data: series.map(p=>p.flow) },
    { label:'temp', data: series.map(p=>p.temp) },
  ]}
  const options:any = { responsive:true, maintainAspectRatio:false, plugins:{legend:{position:'bottom'}} }
  return <div style={{height:320}}><Line data={data} options={options} /></div>
}


import { useEffect, useState } from 'react'
export default function Toast({ message }: { message: string }){
  const [show,setShow] = useState(true)
  useEffect(()=>{ const t=setTimeout(()=>setShow(false), 4000); return ()=>clearTimeout(t) },[])
  if(!show) return null
  return <div className="toast">{message}</div>
}

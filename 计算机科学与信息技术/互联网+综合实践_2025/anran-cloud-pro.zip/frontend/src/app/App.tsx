
import { Outlet, Link, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
export default function App() {
  const nav = useNavigate()
  const [user,setUser] = useState<string | null>(localStorage.getItem('user'))
  useEffect(()=>{ if (!localStorage.getItem('token')) nav('/login') },[])
  function logout(){ localStorage.removeItem('token'); localStorage.removeItem('user'); nav('/login') }
  return (
    <div className="min-h-screen">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="font-bold">安燃云 · 调度中心</div>
          <nav className="space-x-4 text-sm">
            <Link to="/" className="hover:underline">仪表盘</Link>
            <Link to="/alerts" className="hover:underline">告警</Link>
            <Link to="/workorders" className="hover:underline">工单</Link>
            <Link to="/devices" className="hover:underline">设备</Link>
            <Link to="/reports" className="hover:underline">报表</Link>
            <Link to="/resident" className="hover:underline">C端</Link>
            <Link to="/sim" className="hover:underline">模拟器</Link>
          </nav>
          <div className="text-sm">{user ? <span className="mr-3">👤 {user}</span> : null}<button className="btn" onClick={logout}>退出</button></div>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-4 py-6"><Outlet /></main>
    </div>
  )
}

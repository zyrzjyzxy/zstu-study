
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str = "AnRan Cloud Pro API"
    JWT_SECRET: str = "dev-secret-change-me"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 24*60
    DB_URL: str = "sqlite:///./anran_pro.db"
    CORS_ORIGINS: list[str] = ["http://127.0.0.1:5173","http://localhost:5173"]
    SIM_ENABLED: bool = True
    SIM_INTERVAL_SECONDS: float = 1.0
    SIM_ANOMALY_PROB: float = 0.03
    PRESSURE_BASE: float = 1.2
    FLOW_BASE: float = 35.0
    TEMP_BASE: float = 22.0

settings = Settings()

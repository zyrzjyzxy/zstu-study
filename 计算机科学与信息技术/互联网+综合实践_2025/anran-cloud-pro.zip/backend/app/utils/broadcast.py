
from typing import Set, Any
from asyncio import Lock
from starlette.websockets import WebSocket

class Broadcaster:
    def __init__(self):
        self._clients: Set[WebSocket] = set()
        self._lock = Lock()

    async def register(self, ws: WebSocket):
        await ws.accept()
        async with self._lock:
            self._clients.add(ws)

    async def unregister(self, ws: WebSocket):
        async with self._lock:
            if ws in self._clients:
                self._clients.remove(ws)

    async def publish(self, data: Any):
        dead = []
        for ws in list(self._clients):
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            try:
                await ws.close()
            except Exception:
                pass
            await self.unregister(ws)

broadcaster = Broadcaster()

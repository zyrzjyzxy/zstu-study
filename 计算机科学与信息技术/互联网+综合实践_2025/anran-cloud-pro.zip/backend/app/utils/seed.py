
from sqlalchemy.orm import Session
from ..models import User, Device
from .security import hash_password

def seed(db: Session):
    def add_user(username, pwd, role, full_name=""):
        if not db.query(User).filter(User.username==username).first():
            db.add(User(username=username, password_hash=hash_password(pwd), role=role, full_name=full_name))
    add_user("admin","admin123","admin","管理员")
    add_user("dispatcher","123456","dispatcher","调度员")
    add_user("field","123456","field","抢修人员")
    add_user("property","123456","property","物业经理")
    add_user("resident","123456","resident","居民用户")

    if not db.query(Device).first():
        db.add_all([
            Device(name="站点A", lat=30.58, lng=114.30, location_desc="园区北门"),
            Device(name="站点B", lat=30.59, lng=114.28, location_desc="行政楼旁"),
            Device(name="站点C", lat=30.57, lng=114.31, location_desc="宿舍区"),
            Device(name="站点D", lat=30.581, lng=114.295, location_desc="实验楼"),
        ])
    db.commit()


from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from .db import Base, engine, SessionLocal
from .settings import settings
from .routers import auth as r_auth, devices as r_devices, alerts as r_alerts, workorders as r_workorders, reports as r_reports, residents as r_residents, ws as r_ws, simulator as r_sim
from .utils.seed import seed
from .services import simulator

app = FastAPI(title=settings.APP_NAME)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)
with SessionLocal() as db:
    seed(db)

app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

app.include_router(r_auth.router)
app.include_router(r_devices.router)
app.include_router(r_alerts.router)
app.include_router(r_workorders.router)
app.include_router(r_reports.router)
app.include_router(r_residents.router)
app.include_router(r_ws.router)
app.include_router(r_sim.router)

@app.on_event("startup")
async def on_start():
    if settings.SIM_ENABLED:
        simulator.start()

@app.get("/health")
def health():
    return {"ok": True, "app": settings.APP_NAME}


import asyncio, random, math
from datetime import datetime
from sqlalchemy.orm import Session
from ..db import SessionLocal
from ..models import Device, SensorData, Alert
from ..settings import settings
from ..utils.broadcast import broadcaster

_running = False
_task = None

def start():
    global _running, _task
    if not _running:
        _running = True
        _task = asyncio.create_task(_loop())

def stop():
    global _running, _task
    _running = False
    if _task:
        _task.cancel()

async def _loop():
    baseP, baseF, baseT = settings.PRESSURE_BASE, settings.FLOW_BASE, settings.TEMP_BASE
    t = 0.0
    while True:
        if not _running:
            await asyncio.sleep(0.2); continue
        try:
            with SessionLocal() as db:
                devices = db.query(Device).filter(Device.active==True).all()
                for d in devices:
                    t += 0.01
                    pressure = baseP + 0.05*math.sin(t*3.1 + d.id) + random.gauss(0, 0.01)
                    flow = baseF + 2.0*math.sin(t*1.2 + d.id*0.3) + random.gauss(0, 0.3)
                    temp = baseT + 0.2*math.sin(t*0.7 + d.id) + random.gauss(0, 0.05)
                    if random.random() < settings.SIM_ANOMALY_PROB:
                        pressure += random.choice([-0.4, +0.5])
                    rec = SensorData(device_id=d.id, pressure=pressure, flow=flow, temp=temp, ts=datetime.utcnow())
                    db.add(rec); db.commit(); db.refresh(rec)
                    _maybe_alert(db, rec)
        except asyncio.CancelledError:
            break
        except Exception:
            await asyncio.sleep(0.1)
        await asyncio.sleep(settings.SIM_INTERVAL_SECONDS)

def _maybe_alert(db: Session, data: SensorData):
    last = db.query(SensorData).filter(SensorData.device_id==data.device_id, SensorData.id!=data.id).order_by(SensorData.ts.desc()).limit(30).all()
    if len(last) < 10: return None
    pressures = [r.pressure for r in last]
    mean = sum(pressures)/len(pressures)
    var = sum((p-mean)**2 for p in pressures)/len(pressures) or 1e-6
    sigma = var ** 0.5
    resid = abs(data.pressure - mean)
    if resid > 3*sigma or resid/abs(mean) > 0.18:
        level = "L2" if resid/abs(mean) > 0.28 else "L1"
        a = Alert(device_id=data.device_id, level=level, message=f"[SIM] Pressure residual {resid:.3f} vs baseline {mean:.3f}", confidence=min(0.5 + resid/(abs(mean)+1e-6), 0.99))
        db.add(a); db.commit(); db.refresh(a)
        try:
            import asyncio
            asyncio.create_task(broadcaster.publish({
                "type":"alert","id":a.id,"device_id":a.device_id,"level":a.level,"message":a.message,
                "confidence":a.confidence,"created_at":a.created_at.isoformat(),"status":a.status
            }))
        except Exception:
            pass
        return a
    return None

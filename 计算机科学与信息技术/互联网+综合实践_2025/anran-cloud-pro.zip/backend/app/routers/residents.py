
from fastapi import APIRouter, Depends, UploadFile, File, Form
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Alert, Evidence
import os, uuid

router = APIRouter(prefix="/residents", tags=["residents"])
UPLOAD_DIR = "uploads"

@router.post("/odor")
async def odor_report(address: str = Form(...), note: str = Form(""), file: UploadFile = File(None), db: Session = Depends(get_db)):
    alert = Alert(device_id=0, level="L1", message=f"异味快报@{address}: {note}", confidence=0.7)
    db.add(alert); db.commit(); db.refresh(alert)
    if file:
        ext = os.path.splitext(file.filename or "")[1] or ".jpg"
        fname = f"{uuid.uuid4().hex}{ext}"
        path = os.path.join(UPLOAD_DIR, fname)
        with open(path, "wb") as f:
            f.write(await file.read())
        db.add(Evidence(alert_id=alert.id, path=f"/{UPLOAD_DIR}/{fname}", note="居民上传"))
        db.commit()
    return {"ok": True, "alert_id": alert.id}

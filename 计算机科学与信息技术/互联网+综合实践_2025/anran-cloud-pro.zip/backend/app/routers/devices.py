
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime, timedelta
from ..db import get_db
from ..models import Device, SensorData, Alert
from ..schemas import DeviceIn, DeviceOut, IngestIn, SeriesOut, SeriesPoint
from ..auth import get_current_user, require_roles
import statistics

router = APIRouter(prefix="/devices", tags=["devices"])

@router.post("/register", response_model=DeviceOut)
def register_device(payload: DeviceIn, db: Session = Depends(get_db), user=Depends(require_roles("admin","dispatcher"))):
    d = Device(name=payload.name, lat=payload.lat, lng=payload.lng, location_desc=payload.location_desc)
    db.add(d); db.commit(); db.refresh(d)
    return {"id": d.id, "name": d.name, "lat": d.lat, "lng": d.lng, "location_desc": d.location_desc, "active": True}

@router.get("/", response_model=List[DeviceOut])
def list_devices(db: Session = Depends(get_db), user=Depends(get_current_user)):
    items = db.query(Device).all()
    return [DeviceOut(id=i.id, name=i.name, lat=i.lat, lng=i.lng, location_desc=i.location_desc, active=i.active) for i in items]

@router.get("/{device_id}/timeseries", response_model=SeriesOut)
def timeseries(device_id: int, hours: int = 6, db: Session = Depends(get_db), user=Depends(get_current_user)):
    since = datetime.utcnow() - timedelta(hours=hours)
    rows = db.query(SensorData).filter(SensorData.device_id==device_id, SensorData.ts>=since).order_by(SensorData.ts.asc()).all()
    pts = [SeriesPoint(ts=r.ts, pressure=r.pressure, flow=r.flow, temp=r.temp) for r in rows]
    return {"device_id": device_id, "points": pts}

@router.get("/nearby")
def nearby(lat: float, lng: float, radius: float = 2.0, db: Session = Depends(get_db), user=Depends(get_current_user)):
    def dist(a,b,c,d): return ((a-c)**2 + (b-d)**2)**0.5 * 111
    res = []
    for i in db.query(Device).all():
        d = dist(lat,lng,i.lat,i.lng)
        if d <= radius:
            res.append({"id":i.id,"name":i.name,"lat":i.lat,"lng":i.lng,"distance_km":round(d,3)})
    return res

def _detect_and_alert(db: Session, data: SensorData):
    recent = db.query(SensorData).filter(SensorData.device_id==data.device_id, SensorData.id!=data.id).order_by(SensorData.ts.desc()).limit(30).all()
    pressures = [r.pressure for r in recent]
    if len(pressures) < 10: return None
    mean = statistics.mean(pressures)
    stdev = statistics.pstdev(pressures) or 0.01
    resid = abs(data.pressure - mean)
    if resid > 3*stdev or resid/abs(mean or 1.0) > 0.18:
        level = "L2" if resid/abs(mean or 1.0) > 0.28 else "L1"
        alert = Alert(device_id=data.device_id, level=level, message=f"Pressure residual {resid:.3f} vs baseline {mean:.3f}", confidence=min(0.5 + resid/(abs(mean)+1e-6), 0.99))
        db.add(alert); db.commit(); db.refresh(alert)
        try:
            from ..utils.broadcast import broadcaster
            import asyncio
            asyncio.create_task(broadcaster.publish({
                "type":"alert","id":alert.id,"device_id":alert.device_id,"level":alert.level,"message":alert.message,
                "confidence":alert.confidence,"created_at":alert.created_at.isoformat(),"status":alert.status
            }))
        except Exception:
            pass
        return alert
    return None

@router.post("/ingest")
def ingest(payload: IngestIn, db: Session = Depends(get_db), user=Depends(get_current_user)):
    if not db.query(Device).filter(Device.id==payload.device_id).first():
        raise HTTPException(status_code=404, detail="Device not found")
    ts = payload.ts or datetime.utcnow()
    rec = SensorData(device_id=payload.device_id, pressure=payload.pressure, flow=payload.flow, temp=payload.temp, ts=ts)
    db.add(rec); db.commit(); db.refresh(rec)
    alert = _detect_and_alert(db, rec)
    return {"ok": True, "alert_id": getattr(alert, "id", None)}

@router.post("/{device_id}/activate/{flag}")
def activate(device_id:int, flag: bool, db: Session = Depends(get_db), user=Depends(require_roles("admin","dispatcher"))):
    d = db.query(Device).filter(Device.id==device_id).first()
    if not d: raise HTTPException(status_code=404, detail="Not found")
    d.active = flag; db.commit()
    return {"ok": True, "active": d.active}

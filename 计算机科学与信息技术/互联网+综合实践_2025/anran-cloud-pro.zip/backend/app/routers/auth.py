
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..schemas import LoginForm, Token, UserOut
from ..models import User
from ..utils.security import hash_password
from ..auth import login_user

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/login", response_model=Token)
def login(form: LoginForm, db: Session = Depends(get_db)):
    token = login_user(db, form.username, form.password)
    return {"access_token": token}

@router.post("/register", response_model=UserOut)
def register(form: LoginForm, db: Session = Depends(get_db)):
    if db.query(User).filter(User.username==form.username).first():
        raise HTTPException(status_code=400, detail="Username exists")
    u = User(username=form.username, password_hash=hash_password(form.password), role="resident")
    db.add(u); db.commit(); db.refresh(u)
    return {"id": u.id, "username": u.username, "role": u.role, "full_name": u.full_name}

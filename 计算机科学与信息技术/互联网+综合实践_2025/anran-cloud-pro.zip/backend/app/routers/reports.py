
from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import cm
from ..db import get_db
from ..models import Alert, WorkOrder

router = APIRouter(prefix="/reports", tags=["reports"])

@router.get("/daily.csv")
def daily_csv(db: Session = Depends(get_db)):
    alerts = db.query(Alert).all()
    wos = db.query(WorkOrder).all()
    rows = ["type,id,message_or_title,status_or_assignee,created_at"]
    for a in alerts:
        rows.append(f"alert,{a.id},{a.message},{a.status},{a.created_at.isoformat()}")
    for w in wos:
        rows.append(f"workorder,{w.id},{w.title},{w.assignee},{w.created_at.isoformat()}")
    content = "\n".join(rows)
    return Response(content, media_type="text/csv")

@router.get("/daily.pdf")
def daily_pdf(db: Session = Depends(get_db)):
    alerts = db.query(Alert).order_by(Alert.created_at.desc()).limit(50).all()
    wos = db.query(WorkOrder).order_by(WorkOrder.created_at.desc()).limit(50).all()
    from io import BytesIO
    buff = BytesIO()
    c = canvas.Canvas(buff, pagesize=A4)
    w, h = A4
    c.setTitle("AnRan Daily Report")
    c.setFont("Helvetica-Bold",14)
    c.drawString(2*cm, h-2*cm, "安燃云 · 每日报告")
    c.setFont("Helvetica",10)
    c.drawString(2*cm, h-2.7*cm, f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  告警数：{len(alerts)}  工单数：{len(wos)}")

    y = h-3.4*cm
    c.setFont("Helvetica-Bold",12); c.drawString(2*cm, y, "最近告警"); y -= 0.6*cm
    c.setFont("Helvetica",9)
    for a in alerts:
        line = f"#{a.id} [{a.level}] {a.message}  conf={a.confidence:.2f}  {a.created_at.strftime('%H:%M:%S')}  status={a.status}"
        c.drawString(2*cm, y, line[:110]); y -= 0.5*cm
        if y < 2*cm: c.showPage(); y = h-2*cm
    y -= 0.4*cm
    c.setFont("Helvetica-Bold",12); c.drawString(2*cm, y, "最近工单"); y -= 0.6*cm
    c.setFont("Helvetica",9)
    for w0 in wos:
        line = f"#{w0.id} alert={w0.alert_id or '-'} title={w0.title} assignee={w0.assignee} status={w0.status} {w0.created_at.strftime('%H:%M:%S')}"
        c.drawString(2*cm, y, line[:110]); y -= 0.5*cm
        if y < 2*cm: c.showPage(); y = h-2*cm

    c.showPage(); c.save()
    pdf = buff.getvalue(); buff.close()
    return Response(pdf, media_type="application/pdf")

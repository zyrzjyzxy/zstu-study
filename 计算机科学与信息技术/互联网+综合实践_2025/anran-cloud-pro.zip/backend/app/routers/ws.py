
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from ..utils.broadcast import broadcaster

router = APIRouter(tags=["ws"])

@router.websocket("/ws/alerts")
async def ws_alerts(ws: WebSocket):
    await broadcaster.register(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        await broadcaster.unregister(ws)
    except Exception:
        await broadcaster.unregister(ws)


from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from ..db import get_db
from ..models import Alert
from ..schemas import AlertOut
from ..auth import get_current_user, require_roles

router = APIRouter(prefix="/alerts", tags=["alerts"])

@router.get("/", response_model=List[AlertOut])
def list_alerts(db: Session = Depends(get_db), user=Depends(get_current_user)):
    items = db.query(Alert).order_by(Alert.created_at.desc()).limit(300).all()
    return [AlertOut(id=i.id, device_id=i.device_id, level=i.level, message=i.message, confidence=i.confidence, created_at=i.created_at, status=i.status) for i in items]

@router.post("/{alert_id}/ack")
def ack_alert(alert_id: int, db: Session = Depends(get_db), user=Depends(require_roles("dispatcher","admin"))):
    a = db.query(Alert).filter(Alert.id==alert_id).first()
    if not a: raise HTTPException(status_code=404, detail="Not found")
    a.status = "acked"; db.commit(); return {"ok": True}

@router.post("/{alert_id}/close")
def close_alert(alert_id: int, db: Session = Depends(get_db), user=Depends(require_roles("dispatcher","admin"))):
    a = db.query(Alert).filter(Alert.id==alert_id).first()
    if not a: raise HTTPException(status_code=404, detail="Not found")
    a.status = "closed"; db.commit(); return {"ok": True}

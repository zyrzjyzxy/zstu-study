
from fastapi import APIRouter
from ..services import simulator

router = APIRouter(prefix="/simulator", tags=["simulator"])

@router.get("/start")
def start():
    simulator.start(); return {"running": True}

@router.get("/stop")
def stop():
    simulator.stop(); return {"running": False}

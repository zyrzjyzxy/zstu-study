
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List
from ..db import get_db
from ..models import Alert, WorkOrder
from ..schemas import WorkOrderIn, WorkOrderOut
from ..auth import get_current_user, require_roles

router = APIRouter(prefix="/workorders", tags=["workorders"])

@router.post("/from_alert/{alert_id}", response_model=WorkOrderOut)
def create_from_alert(alert_id: int, payload: WorkOrderIn, db: Session = Depends(get_db), user=Depends(require_roles("dispatcher","admin"))):
    a = db.query(Alert).filter(Alert.id==alert_id).first()
    if not a: raise HTTPException(status_code=404, detail="Alert not found")
    w = WorkOrder(alert_id=alert_id, title=payload.title, assignee=payload.assignee, sla_minutes=payload.sla_minutes, details=payload.details)
    db.add(w); db.commit(); db.refresh(w); return w

@router.get("/", response_model=List[WorkOrderOut])
def list_workorders(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(WorkOrder).order_by(WorkOrder.created_at.desc()).all()

@router.post("/{wo_id}/status/{status}")
def update_status(wo_id: int, status: str, db: Session = Depends(get_db), user=Depends(get_current_user)):
    allowed = {"assigned","on_site","processing","retest","closed"}
    if status not in allowed: raise HTTPException(status_code=400, detail="bad status")
    w = db.query(WorkOrder).filter(WorkOrder.id==wo_id).first()
    if not w: raise HTTPException(status_code=404, detail="Not found")
    w.status = status; w.updated_at = datetime.utcnow(); db.commit(); return {"ok": True}

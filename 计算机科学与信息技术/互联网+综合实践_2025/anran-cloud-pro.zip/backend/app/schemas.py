
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class LoginForm(BaseModel):
    username: str
    password: str

class UserOut(BaseModel):
    id: int
    username: str
    role: str
    full_name: str = ""

class DeviceIn(BaseModel):
    name: str
    lat: float
    lng: float
    location_desc: str = ""

class DeviceOut(DeviceIn):
    id: int
    active: bool = True

class IngestIn(BaseModel):
    device_id: int
    pressure: float
    flow: float
    temp: float
    ts: Optional[datetime] = None

class AlertOut(BaseModel):
    id: int
    device_id: int
    level: str
    message: str
    confidence: float
    created_at: datetime
    status: str

class WorkOrderIn(BaseModel):
    title: str
    assignee: str
    sla_minutes: int = 30
    details: str = ""

class WorkOrderOut(BaseModel):
    id: int
    alert_id: Optional[int] = None
    title: str
    assignee: str
    status: str
    sla_minutes: int
    created_at: datetime
    updated_at: datetime
    details: str = ""

class SeriesPoint(BaseModel):
    ts: datetime
    pressure: float
    flow: float
    temp: float

class SeriesOut(BaseModel):
    device_id: int
    points: List[SeriesPoint]

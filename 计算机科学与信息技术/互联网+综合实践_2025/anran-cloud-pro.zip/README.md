
# 安燃云（AnRan Cloud）Pro - 全栈项目（含模拟器/WS/GIS/PDF）

- **后端**：FastAPI + SQLAlchemy + JWT + WebSocket + ReportLab（PDF）  
- **前端**：React + Vite + TypeScript + Tailwind + React-Leaflet + Chart.js  

## 启动
后端：
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8001
```
前端：
```bash
cd frontend
npm install
npm run dev
```
默认地址： http://127.0.0.1:5173 ，后端： http://127.0.0.1:8001

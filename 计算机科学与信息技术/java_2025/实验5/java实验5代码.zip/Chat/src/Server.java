import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Server implements ActionListener {

    JTextField text;
    static JPanel a1;
    static Box vertical = Box.createVerticalBox();
    static JFrame f = new JFrame();

    // 发送消息到客户端
    public void actionPerformed(ActionEvent ae) {
        try {
            String out = text.getText();

            JPanel p2 = formatLabel(out);

            JPanel right = new JPanel(new BorderLayout());
            right.add(p2, BorderLayout.LINE_END);
            vertical.add(right);
            vertical.add(Box.createVerticalStrut(15));

            a1.add(vertical);
            // 向所有客户端发送消息
            for (ClientHandler clientHandler : ClientHandler.clientHandlers) {
                clientHandler.sendMessage(out);  // 向每个客户端发送消息
            }

            text.setText("");

            f.repaint();
            f.revalidate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 格式化消息显示
    public static JPanel formatLabel(String out) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JLabel output = new JLabel("<html><p style=\"width: 150px\">" + out + "</p></html>");
        output.setFont(new Font("Tahoma", Font.PLAIN, 16));
        output.setBackground(new Color(37, 211, 102));
        output.setOpaque(true);
        output.setBorder(new EmptyBorder(15, 15, 15, 50));

        panel.add(output);

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

        JLabel time = new JLabel(sdf.format(cal.getTime()));
        panel.add(time);

        return panel;
    }

    public Server() {
        f.setLayout(null);

        JPanel p1 = new JPanel();
        p1.setBackground(new Color(7, 94, 84));
        p1.setBounds(0, 0, 450, 70);
        p1.setLayout(null);
        f.add(p1);

        // 加载图片资源
        ImageIcon i1 = new ImageIcon(getClass().getResource("/icons/3.png"));
        Image i2 = i1.getImage().getScaledInstance(25, 25, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel back = new JLabel(i3);
        back.setBounds(5, 20, 25, 25);
        p1.add(back);

        back.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent ae) {
                System.exit(0);
            }
        });

        // 加载个人头像图片
        ImageIcon i4 = new ImageIcon(getClass().getResource("/icons/1.png"));
        Image i5 = i4.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel profile = new JLabel(i6);
        profile.setBounds(40, 10, 50, 50);
        p1.add(profile);

        JLabel name = new JLabel("Serve");
        name.setBounds(110, 15, 100, 18);
        name.setForeground(Color.WHITE);
        name.setFont(new Font("SAN_SERIF", Font.BOLD, 18));
        p1.add(name);

        JLabel status = new JLabel("Active Now");
        status.setBounds(110, 35, 100, 18);
        status.setForeground(Color.WHITE);
        status.setFont(new Font("SAN_SERIF", Font.PLAIN, 14));
        p1.add(status);

        a1 = new JPanel();
        a1.setLayout(new BoxLayout(a1, BoxLayout.Y_AXIS));
        a1.setBackground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(a1);
        scrollPane.setBounds(5, 75, 440, 570);
        scrollPane.setBorder(null);
        f.add(scrollPane);

        text = new JTextField();
        text.setBounds(5, 655, 310, 40);
        text.setFont(new Font("SAN_SERIF", Font.PLAIN, 16));
        f.add(text);

        JButton send = new JButton("Send");
        send.setBounds(320, 655, 123, 40);
        send.setBackground(new Color(7, 94, 84));
        send.setForeground(Color.WHITE);
        send.addActionListener(this);
        send.setFont(new Font("SAN_SERIF", Font.PLAIN, 16));
        f.add(send);

        // 使窗口可拖动
        f.setSize(450, 700);
        f.setLocation(200, 50);
        f.setUndecorated(true); // 取消窗口装饰，方便拖动
        f.getContentPane().setBackground(Color.WHITE);

        // 设置鼠标监听器，使得窗口可拖动
        f.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                // 获取鼠标位置，开始拖动
                xMouse = e.getX();
                yMouse = e.getY();
            }
        });

        f.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                // 计算并设置窗口的新位置
                int x = e.getXOnScreen();
                int y = e.getYOnScreen();
                f.setLocation(x - xMouse, y - yMouse);
            }
        });

        f.setVisible(true);
    }

    // 用于记录鼠标位置
    int xMouse, yMouse;

    public static void main(String[] args) {
        new Server();

        try {
            ServerSocket skt = new ServerSocket(6001);
            while (true) {
                // 等待客户端连接
                Socket s = skt.accept();
                System.out.println("客户端已连接");

                // 创建新的线程来处理客户端
                ClientHandler clientHandler = new ClientHandler(s);
                Thread clientThread = new Thread(clientHandler);
                clientThread.start();  // 启动线程
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 客户端处理器线程
    static class ClientHandler implements Runnable {
        private Socket clientSocket;
        private DataInputStream din;
        private DataOutputStream dout;

        // 用于存储所有已连接的客户端
        static List<ClientHandler> clientHandlers = new ArrayList<>();

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try {
                din = new DataInputStream(clientSocket.getInputStream());
                dout = new DataOutputStream(clientSocket.getOutputStream());

                // 将当前的客户端处理器加入到全局列表中
                clientHandlers.add(this);

                // 不断接收客户端消息并显示
                while (true) {
                    String msg = din.readUTF();  // 从客户端读取消息
                    JPanel panel = formatLabel(msg);  // 格式化消息

                    JPanel left = new JPanel(new BorderLayout());
                    left.add(panel, BorderLayout.LINE_START);
                    vertical.add(left);
                    vertical.add(Box.createVerticalStrut(15));

                    a1.add(vertical);
                    f.validate();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // 向客户端发送消息
        public void sendMessage(String message) {
            try {
                dout.writeUTF(message);  // 发送消息到客户端
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

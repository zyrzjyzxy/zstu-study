package ProducerConsumer;

import java.util.List;

class Customer implements Runnable {
    private static final int TIMES = 3;
    private final List<Integer> list;

    public Customer(List<Integer> list) {
        this.list = list;
    }

    @Override
    public void run() {
        for (int i = 0; i < TIMES; i++) {
            synchronized (list) {
                while (list.isEmpty()) {
                    try {
                        System.out.println("【消费者-" + Thread.currentThread().getName() + "】: 仓库为空，P操作失败，进入阻塞...");
                        list.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("【消费者-" + Thread.currentThread().getName() + "】: 被唤醒，准备消费...");
                }

                Integer removed = list.remove(0);
                System.out.println("【消费者-" + Thread.currentThread().getName() + "】: 购买了产品 R" + removed);
                Controller.showList(list);

                list.notifyAll();

                try { Thread.sleep(800); } catch (InterruptedException e) { e.printStackTrace(); }
            }
        }
        System.out.println("【消费者-" + Thread.currentThread().getName() + "】: 任务完成，线程退出。");
    }
}
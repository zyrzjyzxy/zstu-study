package ProducerConsumer;

import java.util.List;

public class Controller {
    public static void showList(List<Integer> list) {
        System.out.println("=============== 缓冲区当前快照 =============");
        if (list.isEmpty()) {
            System.out.println("[ 缓冲区为空 ]");
        } else {
            for (int i = 0; i < list.size(); i++) {
                System.out.println("指针位置[" + i + "] ---------> 商品编号: R" + list.get(i));
            }
        }
        System.out.println("==========================================\n");
    }
}
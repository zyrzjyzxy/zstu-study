package ProducerConsumer;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

class Producer implements Runnable {
    private static final ThreadLocalRandom RANDOM = ThreadLocalRandom.current();
    private static final int TIMES = 3;
    private final List<Integer> list;
    private final int MAX_SIZE;

    public Producer(List<Integer> list, int size) {
        this.list = list;
        this.MAX_SIZE = size;
    }

    @Override
    public void run() {
        for (int i = 0; i < TIMES; i++) {
            synchronized (list) {
                while (list.size() == this.MAX_SIZE) {
                    try {
                        System.out.println("【生产者-" + Thread.currentThread().getName() + "】: 仓库已满，P操作失败，进入阻塞...");
                        list.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("【生产者-" + Thread.currentThread().getName() + "】: 被唤醒，准备生产...");
                }

                int number = RANDOM.nextInt(1000, 9999);
                System.out.println("【生产者-" + Thread.currentThread().getName() + "】: 生产了产品 R" + number);
                list.add(number);
                Controller.showList(list);

                list.notifyAll();

                try { Thread.sleep(500); } catch (InterruptedException e) { e.printStackTrace(); }
            }
        }
        System.out.println("【生产者-" + Thread.currentThread().getName() + "】: 任务完成，线程退出。");
    }
}
package ProducerConsumer;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("================OS 生产者-消费者模拟================");

        System.out.print("请输入生产者线程数量 (建议 >=2): ");
        int producerNum = scanner.nextInt();

        System.out.print("请输入消费者线程数量 (建议 >=2): ");
        int customerNum = scanner.nextInt();

        System.out.print("请输入缓冲区大小 (例如 5): ");
        int capacity = scanner.nextInt();

        System.out.println("=================== 模拟开始 ===================");

        List<Integer> sharedBuffer = new LinkedList<>();

        for (int i = 1; i <= producerNum; i++) {
            Thread p = new Thread(new Producer(sharedBuffer, capacity), "" + i);
            p.start();
        }

        for (int i = 1; i <= customerNum; i++) {
            Thread c = new Thread(new Customer(sharedBuffer), "" + i);
            c.start();
        }

        // scanner.close(); // 保持开启以免报错，或者放在最后
    }
}
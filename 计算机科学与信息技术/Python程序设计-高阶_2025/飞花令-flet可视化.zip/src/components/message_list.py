from typing import List

import flet as ft

from enum import IntEnum
from dataclasses import dataclass


class IMessageType(IntEnum):
    system = 0
    system_load = 1
    user = 2


@dataclass
class Message:
    type: IMessageType
    message: str = ""


class MessageList(ft.ListView):
    def __init__(self, message_list: List[Message]):
        super().__init__([MessageItem(message) for message in message_list], spacing=20, expand=True)

    def append(self, message: Message):
        self.controls.append(MessageItem(message))
        self.update()

    def pop(self):
        self.controls.pop()
        self.update()


class MessageItem(ft.Row):
    def __init__(self, message: Message):
        match message.type:
            case IMessageType.system:
                super().__init__(
                    [
                        ft.Container(
                            ft.Icon(ft.Icons.SETTINGS),
                            width=30,
                        ),
                        ft.Container(
                            ft.Text(message.message, text_align=ft.TextAlign.LEFT),
                            bgcolor=ft.Colors.WHITE,
                            border_radius=10,
                            padding=ft.padding.Padding(10, 5, 10, 5),
                            width=400,
                        ),

                    ],
                    expand=True,
                    vertical_alignment=ft.CrossAxisAlignment.START,
                    alignment=ft.MainAxisAlignment.START,
                )
            case IMessageType.system_load:
                super().__init__(
                    [
                        ft.Container(
                            ft.Icon(ft.Icons.SETTINGS),
                            width=30,
                        ),
                        ft.Container(
                            ft.ProgressRing(width=20, height=20, stroke_width=5),
                            border_radius=10,
                            padding=ft.padding.Padding(10, 5, 10, 5),
                        ),

                    ],
                    expand=True,
                    vertical_alignment=ft.CrossAxisAlignment.START,
                    alignment=ft.MainAxisAlignment.START,
                )
            case IMessageType.user:
                super().__init__(
                    [
                        ft.Container(
                            ft.Text(message.message, text_align=ft.TextAlign.RIGHT),
                            bgcolor=ft.Colors.GREEN_400,
                            border_radius=10,
                            padding=ft.padding.Padding(10, 7, 10, 7),
                            width=400,
                        ),
                        ft.Container(
                            ft.Icon(ft.Icons.PERSON),
                            width=30,
                        ),
                    ],
                    expand=True,
                    vertical_alignment=ft.CrossAxisAlignment.START,
                    alignment=ft.MainAxisAlignment.END,
                )

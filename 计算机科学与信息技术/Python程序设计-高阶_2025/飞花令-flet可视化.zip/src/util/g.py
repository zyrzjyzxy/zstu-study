from typing import Optional, Dict, Any
from util.embedding_loader import *


class GlobalData:
    EmbeddingLoader: Optional[EmbeddingLoader] = None

    @classmethod
    def flash_embedding_loader(cls):
        if cls.EmbeddingLoader is None:
            cls.EmbeddingLoader = EmbeddingLoader(EmbeddingConfig(
                poem_sentences_path="data/model/poem/poem_sentences.pkl",
                poem_embeddings_path="data/model/poem/poem_embeddings.npy",
            ))

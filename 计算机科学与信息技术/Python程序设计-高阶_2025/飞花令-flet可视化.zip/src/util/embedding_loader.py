import pickle
from typing import List, Set, Optional

import faiss
import numpy as np
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer

from util.logger import Logger
import os

__all__ = [
    "EmbeddingLoader",
    "EmbeddingConfig"
]


class EmbeddingConfig(BaseModel):
    poem_sentences_path: str
    poem_embeddings_path: str
    cache_path: Optional[str] = None


class EmbeddingLoader:
    """
    用于加载词向量模型
    """

    def __init__(self, config: EmbeddingConfig):
        if (os.path.exists(path=config.poem_sentences_path) is False or
                os.path.isfile(path=config.poem_sentences_path) is False):
            Logger.new().error(f"加载poem_sentences失败，文件不存在: {config.poem_sentences_path}")
            raise FileNotFoundError(f"{config.poem_sentences_path}")
        with open(config.poem_sentences_path, "rb") as f:
            self.poem_lines = pickle.load(f)
        Logger.new().info(f"加载poem_sentences成功")

        if (os.path.exists(path=config.poem_embeddings_path) is False or
                os.path.isfile(path=config.poem_embeddings_path) is False):
            Logger.new().error(f"加载poem_embeddings失败，文件不存在: {config.poem_embeddings_path}")
            raise FileNotFoundError(f"{config.poem_embeddings_path}")
        embeddings = np.load(config.poem_embeddings_path)

        self.model = SentenceTransformer("shibing624/text2vec-base-chinese", cache_folder=config.cache_path)

        self.index = faiss.IndexFlatL2(embeddings.shape[1])
        # noinspection PyArgumentList
        self.index.add(embeddings)
        Logger.new().info(f"加载poem_embeddings成功")

    def search_poems(self, keyword: str, top_k: int = 100) -> Set[str]:
        assert len(keyword.strip()) == 1
        query_vec = self.model.encode([keyword])
        # noinspection PyArgumentList
        D, I = self.index.search(query_vec, top_k * 5)  # 检索多个备选，避免不足

        selected = set()
        for idx in I[0]:
            if idx >= len(self.poem_lines):
                continue
            line: str = self.poem_lines[idx]
            if keyword in line:
                for i in (",", ".", "，", "。"):
                    line = line.strip(i)
                for i in (",", ".", "，", "。"):
                    if i in line:
                        for j in line.split(i):
                            if keyword in j:
                                selected.add(j)
                        break
                else:
                    selected.add(line)
                if len(selected) >= top_k:
                    break  # 找够就停
        return selected


if __name__ == '__main__':
    config = EmbeddingConfig(
        poem_sentences_path="data/model/poem/poem_sentences.pkl",
        poem_embeddings_path="data/model/poem/poem_embeddings.npy",
    )
    loader = EmbeddingLoader(config)
    print(loader.search_poems("酒"))

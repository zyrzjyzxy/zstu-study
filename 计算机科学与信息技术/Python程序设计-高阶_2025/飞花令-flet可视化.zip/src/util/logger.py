from typing import Optional
from datetime import datetime

__all__ = [
    "Logger"
]


class InnerLogger:
    def __init__(self, fmt: str = "%Y-%m-%d %H:%M:%S"):
        self.fmt = fmt

    def __date(self) -> str:
        return datetime.now().strftime(self.fmt)

    def info(self, message: str):
        print(f"[INFO][{self.__date()}]: {message}")

    def error(self, message: str):
        print(f"\33[0;31m[ERROR][{self.__date()}]: {message}\033[0m")


class Logger:
    _instance: Optional["InnerLogger"] = None

    @classmethod
    def new(cls) -> Optional["InnerLogger"]:
        if cls._instance is None:
            cls._instance = InnerLogger()
        return cls._instance

import random
from typing import Optional

from page.dialog import DialogPage
import flet as ft

from util.g import GlobalData


class EmbeddingDialogPage(DialogPage):
    ROUTE: str = "/embedding"

    def __init__(self, page: ft.Page, title: str, value: str):
        self.result = GlobalData.EmbeddingLoader.search_poems(value)
        super().__init__(page, title, value)

    def get_text(self, index: int) -> Optional[str]:
        for i in self.result:
            if len(i) == self.len_of_line and len(i) > index and i[index] == self.value:
                return i
        return None

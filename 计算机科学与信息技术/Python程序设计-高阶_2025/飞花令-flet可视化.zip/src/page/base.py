from typing import Optional, Sequence

import flet as ft


class BasePage(ft.View):
    ROUTE: str = ""

    def __init__(
            self, page: ft.Page,
            controls: Optional[Sequence[ft.Control]] = None,
    ):
        self.page = page
        super().__init__(self.ROUTE, controls, padding=0)

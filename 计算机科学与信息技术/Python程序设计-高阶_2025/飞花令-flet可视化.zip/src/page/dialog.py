from abc import abstractmethod
import random
from typing import List, Optional

import flet as ft

from components.message_list import MessageList, Message, IMessageType

__all__ = ["DialogPage"]

from page.base import BasePage


class DialogPage(BasePage):
    ROUTE: str = "/dialog"

    def __init__(self, page: ft.Page, title,
                 value
                 ):
        message_list: List[Message] = []
        self.value = value
        self.index = 1
        self.end = False
        self.wrong_count = 0
        self.len_of_line: Optional[int] = None  # None表示初始化
        if random.randint(0, 1) == 0:
            message_list.append(Message(IMessageType.system, "我先来"))
            text = self.get_text(0)
            if text is None:
                text = "这个字没有诗"
                self.end = True
            self.len_of_line = len(text)
            message_list.append(Message(IMessageType.system, text))
        else:
            self.index = 0
            message_list.append(Message(IMessageType.system, "请你先来"))

        self.send_button = ft.ElevatedButton(
            "发送",
            height=40,

            style=ft.ButtonStyle(
                bgcolor=ft.Colors.TRANSPARENT,
                shape=ft.RoundedRectangleBorder(radius=5),
                side=ft.BorderSide(width=2, color=ft.Colors.BLUE_GREY, stroke_align=ft.BorderSideStrokeAlign.INSIDE),
                shadow_color=ft.Colors.TRANSPARENT
            ),
            on_click=self.on_click
        )
        self.message_list = MessageList(message_list)
        self.text_field = ft.TextField(
            expand=True,
            border_radius=5,
            border_width=2,
            border_color=ft.Colors.BLUE_GREY,
            border=ft.InputBorder.UNDERLINE,
            multiline=True
        )
        super().__init__(
            page,
            [
                ft.SafeArea(
                    ft.Container(
                        ft.Column(
                            [
                                ft.Container(
                                    ft.Button(
                                        f"{title} (点击返回)",
                                        on_click=self.on_back_index,
                                        style=ft.ButtonStyle(
                                            bgcolor=ft.Colors.TRANSPARENT,
                                            side=ft.BorderSide(width=0, color=ft.Colors.TRANSPARENT,
                                                               stroke_align=ft.BorderSideStrokeAlign.INSIDE),
                                            shadow_color=ft.Colors.TRANSPARENT
                                        )
                                    ),
                                    alignment=ft.alignment.center
                                ),
                                ft.Column([self.message_list], expand=True, alignment=ft.MainAxisAlignment.START),
                                ft.Row(
                                    [
                                        self.text_field,
                                        self.send_button
                                    ],
                                    height=100,
                                    vertical_alignment=ft.CrossAxisAlignment.END,
                                ),
                            ],
                            spacing=20,
                        ),
                        bgcolor=ft.Colors.GREY_200,
                        padding=10,
                    ),
                    expand=True
                )
            ],
        )

    def on_send(self, _, text: str) -> List[str]:
        if self.len_of_line is None:
            self.len_of_line = len(text)
        if self.end:
            return ["游戏已经结束"]
        if (len(text) > self.len_of_line or
                len(text) <= self.index or
                len(text) > self.index and text[self.index] != self.value):
            self.wrong_count += 1
            if self.wrong_count >= 3:
                self.end = True
                return []
            return [f"你错了哦，还有{3 - self.wrong_count}次机会"]
        self.index += 1
        if self.index >= self.len_of_line:
            self.end = True
            return []
        text = self.get_text(self.index)
        if text is None:
            self.end = True
            return ["呜呜呜我不会了"]
        self.index += 1
        if self.index >= self.len_of_line:
            self.end = True
        return [text]

    @abstractmethod
    def get_text(self, index: int) -> Optional[str]:
        raise NotImplementedError

    @staticmethod
    def on_back_index(event: ft.ControlEvent):
        event.page.go("/")

    def on_click(self, evnet: ft.ControlEvent):
        text = self.text_field.value
        if text is not None:
            self.text_field.value = None
            evnet.page.update()
            self.message_list.append(Message(IMessageType.user, text))
            self.message_list.append(Message(IMessageType.system_load))
            res_text = self.on_send(evnet, text)
            self.message_list.pop()
            for each_res_text in res_text:
                self.message_list.append(Message(IMessageType.system, each_res_text))
            if self.end:
                self.message_list.append(Message(IMessageType.system, "游戏结束"))

from typing import List, Type

import flet as ft
from flet.core.page import RouteChangeEvent

from page.base import BasePage
from page.embedding_dialog import EmbeddingDialogPage
from page.index import IndexPage
from page.loading import LoadingPage
from util.g import GlobalData
import urllib.parse


class RouterController:
    PAGES: List[Type[BasePage]] = [
        IndexPage,
        LoadingPage,
        EmbeddingDialogPage
    ]

    def __init__(self, page: ft.Page):
        self.page = page
        self.page.on_route_change = self.on_route_change
        self.page.go(IndexPage.ROUTE)

    def on_route_change(self, route: RouteChangeEvent):
        self.page.views.clear()
        route = urllib.parse.urlparse(route.route)
        for page in self.PAGES:
            if route.path == page.ROUTE:
                self.page.views.append(
                    page(
                        page=self.page,
                        **{key: value for key, value in urllib.parse.parse_qsl(route.query)}
                    )
                )
        self.page.update()

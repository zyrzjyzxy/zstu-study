import time
import urllib.parse

import flet as ft

from page.embedding_dialog import EmbeddingDialogPage
from util.embedding_loader import EmbeddingLoader, EmbeddingConfig
from util.g import GlobalData

from page.base import BasePage
from page.loading import LoadingPage
from util.logger import Logger


class IndexPage(BasePage):
    ROUTE: str = "/"

    def __init__(self, page: ft.Page):
        self.page = page
        self.textfield = ft.TextField(label="请输入飞花令的“字”", width=200, on_change=self.on_textfield_update)
        self.button = ft.ElevatedButton("开始游戏", width=200, on_click=self.on_click_embedding,
                                        disabled=True)
        super().__init__(
            page,
            controls=[
                ft.SafeArea(
                    content=ft.Container(
                        ft.Row(
                            [
                                ft.Column(
                                    [
                                        ft.Text("欢迎游玩飞花令游戏!", theme_style=ft.TextThemeStyle.HEADLINE_MEDIUM),
                                        self.textfield,
                                        self.button
                                    ],
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                    spacing=30,
                                )
                            ],
                            alignment=ft.MainAxisAlignment.CENTER,
                            expand=True,

                        ),
                        expand=True,
                    ),
                    expand=True,
                )
            ]
        )

    def on_textfield_update(self, _: ft.ControlEvent):
        if len(self.textfield.value) == 1:
            self.button.disabled = False
        else:
            self.button.disabled = True
        self.button.update()

    def on_click_embedding(self, event: ft.ControlEvent):
        if GlobalData.EmbeddingLoader is None:
            try:
                event.page.go(LoadingPage.ROUTE)
                GlobalData.flash_embedding_loader()
            except Exception as ep:
                event.page.go(IndexPage.ROUTE)
                event.page.open(
                    ft.AlertDialog(
                        title=ft.Text("加载词向量模型错误,可能是网络问题"),
                        content=ft.Text(f"错误信息: {ep}"),
                    )
                )
                Logger.new().error(f"加载词向量模型错误,可能是网络问题: {ep}")
                return
        params = {
            "title": f"飞花令 - {self.textfield.value}",
            "value": self.textfield.value,
        }
        event.page.go(f"{EmbeddingDialogPage.ROUTE}?{urllib.parse.urlencode(params)}")

import flet as ft

from page.base import BasePage


class LoadingPage(BasePage):
    ROUTE: str = "/loading"

    def __init__(self, page: ft.Page):
        super().__init__(
            page,
            [
                ft.SafeArea(
                    ft.Row(
                        controls=[
                            ft.Column(
                                [
                                    ft.Text("正在加载，请稍等...", size=20),
                                    ft.ProgressRing(width=50, height=50, stroke_width=5)],
                                expand=True,
                                spacing=30,
                                alignment=ft.MainAxisAlignment.CENTER,
                                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    expand=True
                )
            ]
        )

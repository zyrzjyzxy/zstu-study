import flet as ft

from page.router_contoller import RouterController

disable = False


def main(page: ft.Page):
    RouterController(page)


ft.app(main)

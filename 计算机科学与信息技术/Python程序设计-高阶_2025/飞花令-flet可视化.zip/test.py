line = '坐中有佳客，尊中有美酒。'
selected = []
keyword = "酒"
if keyword in line:
    for i in (",", ".", "，", "。"):
        line = line.strip(i)
    for i in (",", ".", "，", "。"):
        if i in line:
            selected.extend(line.split(i))
            break
    else:
        selected.append(line)
print(selected)

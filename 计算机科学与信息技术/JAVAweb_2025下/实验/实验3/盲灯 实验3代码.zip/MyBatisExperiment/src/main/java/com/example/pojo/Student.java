package com.example.pojo;

public class Student {
    private Integer id;
    private String name;
    private Integer age;
    private Integer cid;

    // 用来存连表查询出来的班级名称
    private String classname;

    public Student() {}

    public Student(Integer id, String name, Integer age, Integer cid) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.cid = cid;
    }

    // Getter 和 Setter
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }
    public Integer getCid() { return cid; }
    public void setCid(Integer cid) { this.cid = cid; }

    public String getClassname() { return classname; }
    public void setClassname(String classname) { this.classname = classname; }

    @Override
    public String toString() {
        // 修改 toString，把班级名称也打印出来
        return "Student{ ID=" + id + ", 姓名='" + name + "', 年龄=" + age +
                ", 班级ID=" + cid + ", 班级名='" + classname + "' }";
    }
}
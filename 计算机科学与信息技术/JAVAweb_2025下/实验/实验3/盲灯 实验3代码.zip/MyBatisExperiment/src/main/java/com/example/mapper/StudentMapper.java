package com.example.mapper;

import com.example.pojo.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface StudentMapper {

    // 【修改点】这里改成了连表查询，这样列表里就能显示班级名字了
    @Select("SELECT s.*, c.classname FROM s_student s LEFT JOIN c_class c ON s.cid = c.id")
    List<Student> selectAllStudents();

    // 【任务1】查询id为2的学生的信息，包括其班级信息
    @Select("SELECT s.*, c.classname FROM s_student s JOIN c_class c ON s.cid = c.id WHERE s.id = #{id}")
    Student selectStudentWithClass(@Param("id") Integer id);

    // 【任务2】修改操作
    @Update("UPDATE s_student SET age = #{age} WHERE id = #{id}")
    int updateStudentAge(@Param("id") Integer id, @Param("age") Integer age);

    // 【任务3】添加操作
    @Insert("INSERT INTO s_student(id, name, age, cid) VALUES(#{id}, #{name}, #{age}, #{cid})")
    int insertStudent(Student student);

    // 【任务4】删除操作
    @Delete("DELETE FROM s_student WHERE name = #{name}")
    int deleteStudentByName(@Param("name") String name);
}
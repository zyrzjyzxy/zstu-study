import com.example.mapper.StudentMapper;
import com.example.pojo.Student;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import java.io.InputStream;
import java.util.List;

public class TestTask3_Insert {
    public static void main(String[] args) throws Exception {
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);

        try (SqlSession session = factory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            System.out.println("========== 任务3：新增验证 ==========");
            // 题目要求：新增一名学生，姓名：刘能，年龄：19，班级：2
            System.out.println("正在新增学生：刘能...");

            // 这里ID设为5，防止重复
            Student newStudent = new Student(5, "刘能", 19, 2);

            int rows = mapper.insertStudent(newStudent);
            System.out.println("新增成功，影响行数：" + rows);

            // 验证结果
            System.out.println("【验证】查询所有学生列表：");
            List<Student> list = mapper.selectAllStudents();
            for (Student s : list) {
                System.out.println(s);
            }
            System.out.println("==================================");
        }
    }
}
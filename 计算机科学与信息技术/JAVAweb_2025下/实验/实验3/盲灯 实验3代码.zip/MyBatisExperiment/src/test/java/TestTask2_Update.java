import com.example.mapper.StudentMapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import java.io.InputStream;

public class TestTask2_Update {
    public static void main(String[] args) throws Exception {
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);

        try (SqlSession session = factory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            System.out.println("========== 任务2：修改验证 ==========");
            // 题目要求：将id为1的学生的年龄更改为30岁
            System.out.println("正在将 ID=1 (张三) 的年龄修改为 30 岁...");

            int rows = mapper.updateStudentAge(1, 30);
            System.out.println("修改成功，影响行数：" + rows);

            // 验证修改结果
            System.out.println("【验证】重新查询 ID=1 的信息：");
            System.out.println(mapper.selectStudentWithClass(1));
            System.out.println("==================================");
        }
    }
}
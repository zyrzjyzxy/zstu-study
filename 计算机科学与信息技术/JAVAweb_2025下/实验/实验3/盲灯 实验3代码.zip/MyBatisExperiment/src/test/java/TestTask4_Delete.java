import com.example.mapper.StudentMapper;
import com.example.pojo.Student;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import java.io.InputStream;
import java.util.List;

public class TestTask4_Delete {
    public static void main(String[] args) throws Exception {
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);

        try (SqlSession session = factory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            System.out.println("========== 任务4：删除验证 ==========");
            // 题目要求：删除学生李四的信息
            System.out.println("正在删除学生：李四...");

            int rows = mapper.deleteStudentByName("李四");
            System.out.println("删除成功，影响行数：" + rows);

            // 验证结果
            System.out.println("【验证】查询所有学生列表（李四应该消失了）：");
            List<Student> list = mapper.selectAllStudents();
            for (Student s : list) {
                System.out.println(s);
            }
            System.out.println("==================================");
        }
    }
}
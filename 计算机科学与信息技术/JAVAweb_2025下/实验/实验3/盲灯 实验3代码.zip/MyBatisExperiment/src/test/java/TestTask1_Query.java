import com.example.mapper.StudentMapper;
import com.example.pojo.Student;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import java.io.InputStream;

public class TestTask1_Query {
    public static void main(String[] args) throws Exception {
        // 1. 加载配置
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);

        try (SqlSession session = factory.openSession(true)) {
            StudentMapper mapper = session.getMapper(StudentMapper.class);

            System.out.println("========== 任务1：查询验证 ==========");
            // 题目要求：查询id为2的学生的信息，包括其班级信息
            System.out.println("正在查询 ID=2 的学生及其班级信息...");

            Student s = mapper.selectStudentWithClass(2);

            System.out.println("查询结果如下：");
            System.out.println(s);
            System.out.println("==================================");
        }
    }
}
document.addEventListener('DOMContentLoaded', () => {

    // --- 1. 状态管理 (数据) (无变化) ---
    let products = [
        { id: 1, name: '香辣鸡', price: 50 },
        { id: 2, name: '麻辣烫', price: 25 },
        { id: 3, name: '酸辣粉', price: 12 },
        { id: 4, name: '油条', price: 1.2 },
        { id: 5, name: '炸鸡柳', price: 15 },
        { id: 6, name: '珍珠奶茶', price: 18 },
    ];
    let cart = [];
    let searchTerm = '';
    let sortBy = null;

    // --- 2. DOM 元素选择器 (无变化) ---
    const searchInput = document.getElementById('search-input');
    const addProductForm = document.getElementById('add-product-form');
    const newProductNameInput = document.getElementById('new-product-name');
    const newProductPriceInput = document.getElementById('new-product-price');
    const productListContainer = document.getElementById('product-list-container');
    const sortByNameBtn = document.getElementById('sort-by-name');
    const sortByPriceBtn = document.getElementById('sort-by-price');
    const cartItemsContainer = document.getElementById('cart-items-container');
    const cartItemCountSpan = document.getElementById('cart-item-count');
    const selectedItemsCountSpan = document.getElementById('selected-items-count');
    const totalAmountSpan = document.getElementById('total-amount');
    const selectAllCheckbox = document.getElementById('select-all-checkbox');
    const checkoutBtn = document.getElementById('checkout-btn');
    const deleteSelectedBtn = document.getElementById('delete-selected-btn');

    // --- 3. 核心功能函数 ---

    /**
     * 渲染商品列表 (无变化)
     */
    function renderProducts() {
        // ... (函数内容同上一个版本，完全未变) ...
        let productsToRender = products.filter(p =>
            p.name.toLowerCase().includes(searchTerm.toLowerCase())
        );

        if (sortBy === 'name') {
            productsToRender.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'));
        } else if (sortBy === 'price') {
            productsToRender.sort((a, b) => a.price - b.price);
        }

        productListContainer.innerHTML = '';
        if (productsToRender.length === 0 && searchTerm) {
            productListContainer.innerHTML = '<p>未找到匹配的商品</p>';
        } else if (productsToRender.length === 0) {
            productListContainer.innerHTML = '<p>暂无商品</p>';
        }

        productsToRender.forEach(product => {
            const cartItem = cart.find(item => item.id === product.id);
            const quantityInCart = cartItem ? cartItem.quantity : 0;

            let actionButtonHTML = '';
            if (quantityInCart > 0) {
                actionButtonHTML = `
                    <div class="product-item-quantity">
                        <button class="btn btn-prod-quantity-minus" data-id="${product.id}">-</button>
                        <span>${quantityInCart}</span>
                        <button class="btn btn-prod-quantity-plus" data-id="${product.id}">+</button>
                    </div>
                `;
            } else {
                actionButtonHTML = `
                    <button class="btn btn-add-to-cart" data-id="${product.id}">
                        <i class="fa-solid fa-cart-plus"></i> 加入购物车
                    </button>
                `;
            }

            const productHTML = `
                <div class="product-item">
                    <h3>${product.name}</h3>
                    <span class="price">¥${product.price.toFixed(2)}</span>
                    <div class="actions">
                        ${actionButtonHTML}
                        <button class="btn btn-delete-product" data-id="${product.id}">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
            productListContainer.innerHTML += productHTML;
        });
    }

    /**
     * 【已更新】渲染购物车
     * 空购物车时显示装饰图
     */
    function renderCart() {
        cartItemsContainer.innerHTML = '';

        if (cart.length === 0) {
            // --- 核心修改：插入装饰图 ---
            cartItemsContainer.innerHTML = `
                <div class="empty-cart-wrapper">
                    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                        <path fill="#F4F7F6" d="M37.1,-43.5C50.2,-37.1,64.3,-26.8,69.5,-13.7C74.7,-0.6,70.9,15.3,62.7,29.1C54.4,42.9,41.7,54.5,27.1,60.8C12.5,67.1,-4,68,-19.1,62.8C-34.1,57.6,-47.8,46.2,-57.1,32.6C-66.4,19.1,-71.4,3.2,-68.8,-10.8C-66.2,-24.8,-56,-36.8,-44.6,-43.6C-33.1,-50.3,-20.5,-51.7,-8.8,-49.6C2.9,-47.5,13.9,-49.9,37.1,-43.5Z" transform="translate(100 100) scale(0.9)" />
                        <g transform="translate(100 100) scale(1.1)" style="font-size: 80px; fill: #6a11cb; opacity: 0.8;">
                            <text x="-40" y="20" class="fa-solid">&#xf291;</text>
                        </g>
                    </svg>
                    <p class="empty-cart-msg">购物车还是空的哦~</p>
                </div>
            `;
            // --- -------------------- ---
        } else {
            cart.forEach(item => {
                const itemHTML = `
                    <div class="cart-item">
                        <input type="checkbox" class="cart-item-checkbox" data-id="${item.id}" ${item.selected ? 'checked' : ''}>
                        <div class="cart-item-info">
                            <span class="name">${item.name}</span>
                            <span class="price">¥${item.price.toFixed(2)}</span>
                        </div>
                        <div class="cart-item-quantity">
                            <button class="btn-quantity-minus" data-id="${item.id}" ${item.quantity <= 1 ? 'disabled' : ''}>-</button>
                            <span>${item.quantity}</span>
                            <button class="btn-quantity-plus" data-id="${item.id}">+</button>
                        </div>
                        <button class="btn-delete-cart-item" data-id="${item.id}">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </div>
                `;
                cartItemsContainer.innerHTML += itemHTML;
            });
        }
        updateCartSummary();
        renderProducts(); // 同步商品列表按钮状态
    }

    /**
     * 更新购物车统计 (无变化)
     */
    function updateCartSummary() {
        // ... (函数内容同上一个版本，完全未变) ...
        let totalItemsInCart = 0;
        let selectedItemsCount = 0;
        let totalAmount = 0;
        let totalQuantityInCart = 0;

        cart.forEach(item => {
            totalItemsInCart++;
            totalQuantityInCart += item.quantity;
            if (item.selected) {
                selectedItemsCount++;
                totalAmount += item.price * item.quantity;
            }
        });

        selectedItemsCountSpan.textContent = `${selectedItemsCount}/${totalItemsInCart}`;
        totalAmountSpan.textContent = `¥${totalAmount.toFixed(2)}`;
        cartItemCountSpan.textContent = `${totalQuantityInCart} 件商品`;
        selectAllCheckbox.checked = (totalItemsInCart > 0 && selectedItemsCount === totalItemsInCart);

        if (selectedItemsCount === 0) {
            checkoutBtn.disabled = true;
            deleteSelectedBtn.disabled = true;
        } else {
            checkoutBtn.disabled = false;
            deleteSelectedBtn.disabled = false;
        }
    }

    /**
     * 处理“添加新商品” (无变化)
     */
    function handleAddProduct(e) {
        // ... (函数内容同上一个版本，完全未变) ...
        e.preventDefault();
        const name = newProductNameInput.value.trim();
        const price = parseFloat(newProductPriceInput.value);

        if (!name || price < 0) {
            alert('请输入有效的商品名称和价格！');
            return;
        }

        const existingProduct = products.find(p => p.name.toLowerCase() === name.toLowerCase());
        if (existingProduct) {
            alert(`商品 "${name}" 已存在，添加失败！`);
            return;
        }

        const newProduct = {
            id: Date.now(),
            name: name,
            price: price
        };
        products.push(newProduct);
        renderProducts();

        newProductNameInput.value = '';
        newProductPriceInput.value = '0';

        alert(`商品 "${name}" 添加成功！`);
    }

    /**
     * 处理商品列表中的点击事件 (无变化)
     */
    function handleProductListClick(e) {
        // ... (函数内容同上一个版本，完全未变) ...
        const target = e.target.closest('button');
        if (!target) return;

        const id = parseInt(target.dataset.id);
        const product = products.find(p => p.id === id);
        if (!product) return;

        let cartItem = cart.find(item => item.id === id);

        if (target.classList.contains('btn-add-to-cart')) {
            cart.push({ ...product, quantity: 1, selected: true });
        }
        else if (target.classList.contains('btn-prod-quantity-plus')) {
            if (cartItem) cartItem.quantity++;
        }
        else if (target.classList.contains('btn-prod-quantity-minus')) {
            if (cartItem) {
                cartItem.quantity--;
                if (cartItem.quantity === 0) {
                    cart = cart.filter(item => item.id !== id);
                }
            }
        }
        else if (target.classList.contains('btn-delete-product')) {
            if (confirm(`确定要从商品列表删除“${product.name}”吗？\n(这也会将其从购物车移除)`)) {
                products = products.filter(p => p.id !== id);
                cart = cart.filter(item => item.id !== id);
            }
        }

        renderProducts();
        renderCart();
    }

    /**
     * 处理购物车内的点击事件 (无变化)
     */
    function handleCartClick(e) {
        // ... (函数内容同上一个版本，完全未变) ...
        const target = e.target.closest('button');
        if (!target) return;

        const id = parseInt(target.dataset.id);
        const cartItem = cart.find(item => item.id === id);
        if (!cartItem) return;

        if (target.classList.contains('btn-quantity-plus')) {
            cartItem.quantity++;
        }
        else if (target.classList.contains('btn-quantity-minus')) {
            if (cartItem.quantity > 1) {
                cartItem.quantity--;
            }
        }
        else if (target.classList.contains('btn-delete-cart-item')) {
            cart = cart.filter(item => item.id !== id);
        }

        renderCart();
    }

    /**
     * 处理购物车内的“选中”状态改变 (无变化)
     */
    function handleCartChange(e) {
        // ... (函数内容同上一个版本，完全未变) ...
        if (!e.target.classList.contains('cart-item-checkbox')) return;
        const id = parseInt(e.target.dataset.id);
        const cartItem = cart.find(item => item.id === id);
        if (cartItem) {
            cartItem.selected = e.target.checked;
        }
        updateCartSummary();
    }

    /**
     * 处理“全选”复选框 (无变化)
     */
    function handleSelectAll() {
        // ... (函数内容同上一个版本，完全未变) ...
        const isChecked = selectAllCheckbox.checked;
        cart.forEach(item => {
            item.selected = isChecked;
        });
        renderCart();
    }

    /**
     * 处理“立即结算” (无变化)
     */
    function handleCheckout() {
        // ... (函数内容同上一个版本，完全未变) ...
        const totalAmountText = totalAmountSpan.textContent;
        const amount = parseFloat(totalAmountText.replace('¥', ''));
        if (amount === 0) return;

        if (confirm(`您确认要支付 ${totalAmountText} 吗？`)) {
            alert(`支付成功！您已成功支付 ${totalAmountText}！`);
            cart = cart.filter(item => !item.selected);
            renderCart();
        }
    }

    /**
     * 处理“删除选中” (无变化)
     */
    function handleDeleteSelected() {
        // ... (函数内容同上一个版本，完全未变) ...
        const selectedCount = cart.filter(item => item.selected).length;
        if (selectedCount === 0) return;

        if (confirm(`确定要从购物车删除选中的 ${selectedCount} 种商品吗？`)) {
            cart = cart.filter(item => !item.selected);
            renderCart();
        }
    }

    /**
     * 处理搜索输入 (无变化)
     */
    function handleSearch(e) {
        // ... (函数内容同上一个版本，完全未变) ...
        searchTerm = e.target.value;
        renderProducts();
    }

    // --- 4. 事件监听器绑定 (无变化) ---
    searchInput.addEventListener('input', handleSearch);
    addProductForm.addEventListener('submit', handleAddProduct);
    sortByNameBtn.addEventListener('click', () => { sortBy = 'name'; renderProducts(); });
    sortByPriceBtn.addEventListener('click', () => { sortBy = 'price'; renderProducts(); });
    productListContainer.addEventListener('click', handleProductListClick);
    cartItemsContainer.addEventListener('click', handleCartClick);
    cartItemsContainer.addEventListener('change', handleCartChange);
    selectAllCheckbox.addEventListener('change', handleSelectAll);
    deleteSelectedBtn.addEventListener('click', handleDeleteSelected);
    checkoutBtn.addEventListener('click', handleCheckout);

    // --- 5. 初始加载 (无变化) ---
    renderProducts();
    renderCart();
});
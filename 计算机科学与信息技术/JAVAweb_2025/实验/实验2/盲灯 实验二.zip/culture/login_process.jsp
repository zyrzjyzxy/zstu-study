<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    // 1. 设置编码
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html; charset=UTF-8");

    // 2. 获取表单数据
    String username = request.getParameter("username");
    String password = request.getParameter("password");

    // --- 数据库连接信息 ---
    // --- 数据库连接信息 ---
    String dbUser = "root";
    String dbPassword = "20051008"; // 改成这样
    String dbUrl = "jdbc:mysql://localhost:3306/culture_db?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai";
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    try {
        // 3. 加载驱动
        Class.forName("com.mysql.cj.jdbc.Driver");

        // 4. 建立连接
        conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);

        // 5. 准备 SQL 语句 (查询用户名和密码是否都匹配)
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, username);
        pstmt.setString(2, password);

        // 6. 执行查询
        rs = pstmt.executeQuery();

        // 7. 处理结果
        if (rs.next()) {
            // 登录成功 (rs.next() 为 true, 说明查到了数据)

            // 转发到首页 (注意 <jsp:forward> 后面不能有空格)
%><jsp:forward page="index.html" /><%

} else {
    // 登录失败 (没查到数据)
%>
<script>
    alert("登录失败：用户名 (姓名全拼) 或密码 (学号) 错误！");
    window.location.href = "login.jsp";
</script>
<%
    }
} catch (Exception e) {
    // 捕获所有异常 (比如数据库连不上)
    e.printStackTrace();
%>
<script>
    alert("登录失败：发生系统错误。请检查数据库连接或驱动。");
    window.location.href = "login.jsp";
</script>
<%
    } finally {
        // 8. 关闭连接
        if (rs != null) try { rs.close(); } catch (SQLException e) {}
        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) {}
        if (conn != null) try { conn.close(); } catch (SQLException e) {}
    }
%>
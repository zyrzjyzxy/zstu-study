// 确保DOM加载完毕后再执行
document.addEventListener("DOMContentLoaded", function() {

    let slideIndex = 0; // 当前显示的幻灯片索引
    let slides = document.getElementsByClassName("carousel-slide");
    let dots = document.getElementsByClassName("dot");
    let slideTimer; // 用于自动播放的计时器

    // 显示指定的幻灯片
    function showSlide(n) {
        // 索引循环
        if (n >= slides.length) {
            slideIndex = 0;
        } else if (n < 0) {
            slideIndex = slides.length - 1;
        } else {
            slideIndex = n;
        }

        // 1. 隐藏所有幻灯片
        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }

        // 2. 移除所有点的 'active' 状态
        for (let i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }

        // 3. 显示当前幻灯片并激活对应的点
        if (slides[slideIndex]) { // 检查元素是否存在
            slides[slideIndex].style.display = "block";
            dots[slideIndex].className += " active";
        }
    }

    // 自动播放函数
    function autoPlay() {
        slideIndex++;
        showSlide(slideIndex);
    }

    // 设置自动轮播
    function startSlideShow() {
        // 每3秒切换一次 (3000毫秒)
        slideTimer = setInterval(autoPlay, 3000);
    }

    // (全局函数) 允许点点击切换
    // 我们需要把它挂载到 window 对象上，HTML 中的 onclick 才能找到它
    window.currentSlide = function(n) {
        // 重置计时器
        clearInterval(slideTimer); 
        showSlide(n);
        // 重新开始自动播放
        startSlideShow(); 
    }

    // 初始显示第一张
    showSlide(slideIndex);
    // 开始自动播放
    startSlideShow();
});

/* =========================================
   以下是子页面内容切换功能
========================================= */
function showContent(contentId) {
    // 1. 获取所有内容块
    var blocks = document.getElementsByClassName('content-block');
    
    // 2. 隐藏所有内容块
    for (var i = 0; i < blocks.length; i++) {
        blocks[i].classList.remove('active');
    }
    
    // 3. 显示指定的内容块
    var targetBlock = document.getElementById(contentId);
    if (targetBlock) {
        targetBlock.classList.add('active');
    }
}
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.sql.*" %>
<%
    // 1. 设置编码
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html; charset=UTF-8");

    // 2. 获取表单数据
    String username = request.getParameter("username");
    String password = request.getParameter("password"); // 你的学号

    // --- 数据库连接信息 ---
    String dbUser = "root";
    String dbPassword = "20051008"; // 你的密码
    String dbUrl = "jdbc:mysql://localhost:3306/culture_db?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai";

    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        // 3. 加载驱动
        Class.forName("com.mysql.cj.jdbc.Driver");

        // 4. 建立连接
        conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);

        // 5. 准备 SQL 语句
        String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, username);
        pstmt.setString(2, password);

        // 6. 执行插入
        int rows = pstmt.executeUpdate();

        if (rows > 0) {
            // 注册成功

            // *** 关键修改 ***
            // 满足要求 1 和 5：注册成功后重定向到首页 (使用 <jsp:forward>)
            // (注意 <jsp:forward> 后面不能有任何空格或换行)
%><jsp:forward page="index.html" /><%

    }
} catch (SQLIntegrityConstraintViolationException e) {
    // 捕获“用户名重复”的特定异常
%>
<script>
    alert("注册失败：该用户名 (姓名全拼) 已经被注册了！");
    window.location.href = "register.jsp";
</script>
<%
} catch (Exception e) {
    // 捕获其他所有异常
    e.printStackTrace();
%>
<script>
    alert("注册失败：发生系统错误。请检查数据库连接或驱动。");
    window.location.href = "register.jsp";
</script>
<%
    } finally {
        // 7. 关闭连接
        if (pstmt != null) try { pstmt.close(); } catch (SQLException e) {}
        if (conn != null) try { conn.close(); } catch (SQLException e) {}
    }
%>
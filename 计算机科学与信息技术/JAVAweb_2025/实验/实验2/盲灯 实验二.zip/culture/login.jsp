<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>传统文化网 - 登录</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="top-bar">
    <div class="container">
        <span>欢迎访问传统文化网!</span>
        <div class="top-links">
            <a href="#">手机版</a>
            <a href="#">收藏本站</a>
        </div>
    </div>
</div>
<header class="container">
    <div class="logo">
        <img src="img/传统文化2.jpg" alt="传统文化网 Logo">
        <div class="logo-text">
            <h1>传统文化网</h1>
            <p>弘扬传统美德，继承传统文化</p>
        </div>
    </div>
    <div class="header-right">
        <div class="auth-buttons">
            <a href="login.jsp" class="btn btn-login">登录</a>
            <a href="register.jsp" class="btn btn-register">注册</a>
        </div>
        <form class="search-bar">
            <input type="text" placeholder="请输入关键词">
            <button type="submit">搜索</button>
        </form>
    </div>
</header>

<nav>
    <div class="container">
        <ul>
            <li><a href="index.html">首页</a></li>
            <li><a href="guoxue.html">国学百家</a></li>
            <li><a href="festivals.html">传统节日</a></li>
            <li><a href="#">健康文化</a></li>
            <li><a href="#">人文地理</a></li>
            <li><a href="#">文学艺术</a></li>
            <li><a href="#">华夏历史</a></li>
        </ul>
    </div>
</nav>

<main class="container sub-page">
    <div class="auth-form-container">
        <h3>用户登录</h3>
        <form action="login_process.jsp" method="POST" class="auth-form">
            <div class="form-group">
                <label for="username">姓名全拼 (Username)</label>
                <input type="text" id="username" name="username" placeholder="请输入姓名全拼 (例如: zhangsan)">
            </div>
            <div class="form-group">
                <label for="password">学号 (Password)</label>
                <input type="password" id="password" name="password" placeholder="请输入你的学号">
            </div>

            <button type="submit" class="btn-submit">登录</button>

            <div class="form-links">
                <a href="#">忘记密码?</a>
                <span>没有账号? <a href="register.jsp">立即注册</a></span>
            </div>
        </form>
    </div>
</main>

<footer>
    <div class="container">
        <p>20233337621072 黄红洲所制作</p>
    </div>
</footer>

</body>
</html>
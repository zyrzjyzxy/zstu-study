<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>传统文化网 - 注册</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="top-bar"><div class="container"><span>欢迎访问传统文化网!</span><div class="top-links"><a href="#">手机版</a><a href="#">收藏本站</a></div></div></div>
<header class="container"><div class="logo"><img src="img/传统文化2.jpg" alt="传统文化网 Logo"><div class="logo-text"><h1>传统文化网</h1><p>弘扬传统美德，继承传统文化</p></div></div><div class="header-right"><div class="auth-buttons"><a href="login.jsp" class="btn btn-login">登录</a><a href="register.jsp" class="btn btn-register">注册</a></div><form class="search-bar"><input type="text" placeholder="请输入关键词"><button type="submit">搜索</button></form></div></header>

<nav><div class="container"><ul><li><a href="index.html">首页</a></li><li><a href="guoxue.html">国学百家</a></li><li><a href="festivals.html">传统节日</a></li><li><a href="#">健康文化</a></li><li><a href="#">人文地理</a></li><li><a href="#">文学艺术</a></li><li><a href="#">华夏历史</a></li></ul></div></nav>

<main class="container sub-page">
    <div class="auth-form-container">
        <h3>新用户注册</h3>

        <form action="register_process.jsp" method="POST" class="auth-form" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="reg-username">姓名全拼 (Username)</label>
                <input type="text" id="reg-username" name="username" placeholder="请输入姓名全拼 (例如: huanghongzhou)" required>
            </div>
            <div class="form-group">
                <label for="reg-password">学号 (Password)</label>
                <input type="password" id="reg-password" name="password" placeholder="请输入你的学号" required>
            </div>

            <button type="submit" class="btn-submit">注册</button>

            <div class="form-links">
                <span>已有账号? <a href="login.jsp">立即登录</a></span>
            </div>
        </form>
    </div>
</main>

<footer><div class="container"><p>20233337621072 黄红洲所制作</p></div></footer>

<script>
    function validateForm() {
        // 1. 获取用户名的值
        var username = document.getElementById('reg-username').value;

        // 2. 定义一个只允许字母的正则表达式 (a-z 和 A-Z)
        var regex = /^[a-zA-Z]+$/;

        // 3. 检查用户名是否匹配
        if (regex.test(username)) {
            // 验证通过，允许表单提交
            return true;
        } else {
            // 验证失败，弹出提示 (要求 1)
            alert("注册失败：用户名只能由字母组成！");
            // 阻止表单提交
            return false;
        }
    }
</script>

</body>
</html>